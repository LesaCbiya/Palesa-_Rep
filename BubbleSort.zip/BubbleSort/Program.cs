﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BubbleSort
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            foreach (var item in Sort(GetNumbers()))
            {
                Console.WriteLine(item);
            }  
            Console.ReadLine();
        }
        static int[] GetNumbers()
        {
            int[] numbers = new int[5];

            for (int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine("Give value for number "+ (i+1));
                numbers[i] = int.Parse(Console.ReadLine());
            }

            return numbers;
        }
        static int[] Sort(int[] numbers)
        {
            
            int temp;
            for (int j = 0; j <= numbers.Length - 2; j++)
            {
                for (int i = 0; i <= numbers.Length - 2; i++)
                {
                    if (numbers[i] > numbers[i + 1])
                    {
                        temp = numbers[i + 1];
                        numbers[i + 1] = numbers[i];
                        numbers[i] = temp;
                    }
                }
            }
            return numbers;

        }
    }
}
